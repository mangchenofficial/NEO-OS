#include "window.h"
#include "video.h"

static window_t windows[MAX_WINDOWS];
static int window_count = 0;
static u32 next_z_order = 0;

void window_manager_init() {
    window_count = 0;
    for (int i = 0; i < MAX_WINDOWS; i++) {
        windows[i].visible = 0;
        windows[i].active = 0;
        windows[i].z_order = 0;
        windows[i].dragging = 0;
        windows[i].drag_offset_x = 0;
        windows[i].drag_offset_y = 0;
    }
}

window_t* window_create(u32 x, u32 y, u32 w, u32 h, const char* title) {
    if (window_count >= MAX_WINDOWS) return 0;
    
    window_t* win = &windows[window_count++];
    win->x = x;
    win->y = y;
    win->w = w;
    win->h = h;
    win->active = 1;
    win->visible = 1;
    win->z_order = next_z_order++;
    win->dragging = 0;
    win->drag_offset_x = 0;
    win->drag_offset_y = 0;
    
    int i = 0;
    while (title[i] && i < 63) {
        win->title[i] = title[i];
        i++;
    }
    win->title[i] = '\0';
    
    return win;
}

int window_in_titlebar(window_t* win, u32 mx, u32 my) {
    if (!win || !win->visible) return 0;
    u32 title_h = 12;
    return (mx >= win->x && mx < win->x + win->w &&
            my >= win->y && my < win->y + title_h);
}

void window_start_drag(window_t* win, u32 mx, u32 my) {
    if (!win) return;
    win->dragging = 1;
    win->drag_offset_x = (s32)mx - (s32)win->x;
    win->drag_offset_y = (s32)my - (s32)win->y;
}

void window_drag_update(window_t* win, u32 mx, u32 my) {
    if (!win || !win->dragging) return;
    s32 new_x = (s32)mx - win->drag_offset_x;
    s32 new_y = (s32)my - win->drag_offset_y;
    
    if (new_x < 0) new_x = 0;
    if (new_y < 0) new_y = 0;
    
    win->x = (u32)new_x;
    win->y = (u32)new_y;
}

void window_stop_drag(window_t* win) {
    if (!win) return;
    win->dragging = 0;
}

void window_draw(window_t* win) {
    if (!win || !win->visible) return;
    
    u32 title_h = 12;
    u32 border_color = win->active ? 0x0F : 0x08;
    u32 title_color = win->active ? 0x01 : 0x08;
    u32 body_color = 0x07;
    
    fill_rect(win->x, win->y, win->w, title_h, title_color);
    
    fill_rect(win->x, win->y + title_h, win->w, win->h - title_h, body_color);
    
    fill_rect(win->x, win->y, 1, win->h, border_color);
    fill_rect(win->x + win->w - 1, win->y, 1, win->h, border_color);
    fill_rect(win->x, win->y, win->w, 1, border_color);
    fill_rect(win->x, win->y + win->h - 1, win->w, 1, border_color);
    
    draw_string(win->x + 2, win->y + 2, win->title, 0x0F);
}

void window_draw_all() {
    for (u32 z = 0; z < next_z_order; z++) {
        for (int i = 0; i < window_count; i++) {
            if (windows[i].visible && windows[i].z_order == z) {
                window_draw(&windows[i]);
                break;
            }
        }
    }
}

int window_contains(window_t* win, u32 mx, u32 my) {
    if (!win || !win->visible) return 0;
    return (mx >= win->x && mx < win->x + win->w &&
            my >= win->y && my < win->y + win->h);
}

window_t* window_find_at(u32 mx, u32 my) {
    window_t* top_win = 0;
    u32 top_z = 0;
    
    for (int i = 0; i < window_count; i++) {
        if (windows[i].visible && window_contains(&windows[i], mx, my)) {
            if (!top_win || windows[i].z_order > top_z) {
                top_win = &windows[i];
                top_z = windows[i].z_order;
            }
        }
    }
    return top_win;
}

void window_bring_to_front(window_t* win) {
    if (!win) return;
    
    for (int i = 0; i < window_count; i++) {
        windows[i].active = 0;
    }
    win->active = 1;
    win->z_order = next_z_order++;
}
