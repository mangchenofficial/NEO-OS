#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <stdint.h>

void keyboard_init();
char keyboard_getchar();
char* keyboard_readline();
void keyboard_handle_scancode(uint8_t scancode);
void keyboard_handle_interrupt();
int keyboard_has_key();
char keyboard_pop_key();

#endif
