#ifndef DESKTOP_H
#define DESKTOP_H

void desktop_init();
void desktop_draw();
void desktop_update();

#endif
